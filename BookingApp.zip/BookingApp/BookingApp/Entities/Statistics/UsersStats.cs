﻿namespace BookingApp.Entities.Statistics
{
    public class UsersStats
    {        
        public int RegisteredUsers { get; set; }        
        public int ActiveUsers { get; set; }        
        public int BlockedUsers { get; set; }
    }
}
