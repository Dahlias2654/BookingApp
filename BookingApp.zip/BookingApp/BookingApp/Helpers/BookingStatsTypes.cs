﻿namespace BookingApp.Helpers
{
    public enum BookingStatsTypes
    {       
        Creations,
        Cancellations,
        Completions,
        Terminations    
    }
}
