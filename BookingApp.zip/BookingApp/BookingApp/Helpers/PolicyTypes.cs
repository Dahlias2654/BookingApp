﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingApp.Helpers
{
    public static class PolicyTypes
    {
        public const string NotBanned = "NotBanned";
    }
}
