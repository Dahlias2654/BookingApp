﻿namespace BookingApp.Helpers
{
    public static class JwtCustomClaimNames
    {
        public const string UserID = "uid";
    }
}