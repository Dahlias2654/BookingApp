﻿namespace BookingApp.Helpers
{
    public static class RoleTypes
    {
        public const string User = "User";
        public const string Admin = "Admin";
    }
}
