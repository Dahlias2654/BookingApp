export class AuthLogin {
  email: string;
  password: string;
}
