"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BookingStats = /** @class */ (function () {
    function BookingStats() {
    }
    return BookingStats;
}());
exports.BookingStats = BookingStats;
//# sourceMappingURL=stats-booking.js.map