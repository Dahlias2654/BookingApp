export class User {
  id: string;
  email: string;
  userName: string;
  approvalStatus?: boolean;
  isBlocked?: boolean;
}
