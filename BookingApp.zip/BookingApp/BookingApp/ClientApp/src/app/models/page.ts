export class Page {
  TotalItems: number;
  PageNumber: number;
  PageSize: number;
  TotalPages: number;
  arrayTotalPages: any[];
}
