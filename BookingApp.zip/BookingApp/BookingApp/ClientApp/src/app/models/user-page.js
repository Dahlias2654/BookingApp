"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserPage = /** @class */ (function () {
    function UserPage() {
    }
    return UserPage;
}());
exports.UserPage = UserPage;
//# sourceMappingURL=user-page.js.map