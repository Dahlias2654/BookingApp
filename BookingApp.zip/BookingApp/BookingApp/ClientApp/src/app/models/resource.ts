export class Resource {
  id: number;
  title: string;
  isActive: boolean;
  ruleId: number;
  folderId?: number;
  description?: string;
}
