export class ResourceStatsBrief {
  id: number;
  title: string;
  bookingsCount: number;
}
