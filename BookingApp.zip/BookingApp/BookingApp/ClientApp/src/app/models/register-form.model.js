"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RegisterFormModel = /** @class */ (function () {
    function RegisterFormModel(userName, email, password, confirmPassword) {
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }
    return RegisterFormModel;
}());
exports.RegisterFormModel = RegisterFormModel;
//# sourceMappingURL=register-form.model.js.map