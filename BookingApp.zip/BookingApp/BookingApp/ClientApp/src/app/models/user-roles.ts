export class UserRole {
  Role: string;
}
