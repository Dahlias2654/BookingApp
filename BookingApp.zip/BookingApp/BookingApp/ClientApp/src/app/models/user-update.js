"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserUpdate = /** @class */ (function () {
    function UserUpdate() {
    }
    return UserUpdate;
}());
exports.UserUpdate = UserUpdate;
//# sourceMappingURL=user-update.js.map