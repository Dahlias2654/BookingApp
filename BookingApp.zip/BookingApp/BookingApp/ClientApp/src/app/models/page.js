"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Page = /** @class */ (function () {
    function Page() {
    }
    return Page;
}());
exports.Page = Page;
//# sourceMappingURL=page.js.map