export class UsersStats {
  registeredUsers: number;
  activeUsers: number;
  blockedUsers: number;
}
