"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TreeNode = /** @class */ (function () {
    function TreeNode(nesting, title, item, children) {
        this.nesting = nesting;
        this.title = title;
        this.item = item;
        this.children = children;
    }
    return TreeNode;
}());
exports.TreeNode = TreeNode;
//# sourceMappingURL=tree-node.js.map