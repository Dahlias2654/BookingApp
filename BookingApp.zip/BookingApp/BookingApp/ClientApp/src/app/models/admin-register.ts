export class AdminRegister {
  userName: string;
  email: string;
}
