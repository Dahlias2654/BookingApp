"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AuthLogin = /** @class */ (function () {
    function AuthLogin() {
    }
    return AuthLogin;
}());
exports.AuthLogin = AuthLogin;
//# sourceMappingURL=auth-login.js.map