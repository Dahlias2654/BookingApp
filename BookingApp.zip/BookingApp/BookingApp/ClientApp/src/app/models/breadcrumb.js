"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Resource = /** @class */ (function () {
    function Resource() {
    }
    return Resource;
}());
exports.Resource = Resource;
//# sourceMappingURL=resource.js.map