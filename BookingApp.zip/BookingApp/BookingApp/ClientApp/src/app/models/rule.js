"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rule = /** @class */ (function () {
    function rule() {
    }
    return rule;
}());
exports.rule = rule;
//# sourceMappingURL=rule.js.map