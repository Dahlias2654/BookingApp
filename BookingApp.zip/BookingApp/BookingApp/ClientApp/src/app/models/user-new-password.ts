export class UserNewPassword {
  NewPassword: string;
  ConfirmNewPassword: string;
  CurrentPassword?: string;
  RestoreToken?: string;
}
