"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ResourceTimeWindowType;
(function (ResourceTimeWindowType) {
    ResourceTimeWindowType[ResourceTimeWindowType["My"] = 0] = "My";
    ResourceTimeWindowType[ResourceTimeWindowType["Booked"] = 1] = "Booked";
    ResourceTimeWindowType[ResourceTimeWindowType["ServiceTime"] = 2] = "ServiceTime";
    ResourceTimeWindowType[ResourceTimeWindowType["Lost"] = 3] = "Lost";
    ResourceTimeWindowType[ResourceTimeWindowType["Free"] = 4] = "Free";
})(ResourceTimeWindowType = exports.ResourceTimeWindowType || (exports.ResourceTimeWindowType = {}));
var ResourceTimeWindow = /** @class */ (function () {
    function ResourceTimeWindow() {
    }
    return ResourceTimeWindow;
}());
exports.ResourceTimeWindow = ResourceTimeWindow;
//# sourceMappingURL=resource-time-window.js.map