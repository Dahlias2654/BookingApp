export class UserUpdate {
  userName: string;
  email?: string;
}
