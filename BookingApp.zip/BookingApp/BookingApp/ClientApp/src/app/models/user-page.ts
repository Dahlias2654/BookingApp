import { Page } from "./page";
import { User } from "./user";

export class UserPage {
  paging: Page;
  items: User[];
}
