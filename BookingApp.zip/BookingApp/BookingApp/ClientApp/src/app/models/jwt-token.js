"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var JwtToken = /** @class */ (function () {
    function JwtToken() {
    }
    return JwtToken;
}());
exports.JwtToken = JwtToken;
//# sourceMappingURL=jwt-token.js.map