"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BASE_API_URL = document.location.protocol + '/api';
//# sourceMappingURL=globals.js.map