import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-admin-user',
  templateUrl: './user.component.html'
})
export class UserComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {  
  }

}
