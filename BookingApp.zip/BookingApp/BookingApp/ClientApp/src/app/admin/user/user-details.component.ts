import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-admin-user-details',
  templateUrl: './user-details.component.html'
})
export class UserDetailsComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {  
  }

}
