"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var folder_edit_component_1 = require("../../admin/folder/folder-edit.component");
var testing_1 = require("@angular/core/testing");
describe('Component: FolderEdit', function () {
    var component;
    var fixture;
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [folder_edit_component_1.FolderEditComponent]
        });
        // create component and test fixture
        fixture = testing_1.TestBed.createComponent(folder_edit_component_1.FolderEditComponent);
        // get test component from the fixture
        component = fixture.componentInstance;
    });
});
//# sourceMappingURL=folder-edit.component.spec.js.map