﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingApp.DTOs
{
    public class UserRoleDto
    {
        public virtual string Role { get; set; }
    }
}
